package projet;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import data.Groupegrp;

/**
 * DAO abstrait et g�n�rique pour tout type de donn�es.
 * @author Jerome
 */
public class Groupe {


    EntityManager em;  
    
    public Groupe() throws DAOException {
    	super();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("projet");
    	em = emf.createEntityManager(); 
    }
   /**
     * Retourne � partir du support de persistance un objet en fonction de son identifiant.
     * @param id identifiant de l'objet
     * @return l'instance de l'objet
     * @throws DAOException en cas de probl�me
    */
    public Groupegrp find(int id) throws DAOException{
    	return em.find(Groupegrp.class, id );
    }

    /**
     * Rend persistant un objet qui n'avait pas encore de r�pr�sentation sur 
     * le support de persistance.
     * @param data l'objet � rendre persistant
     * @throws DAOException en cas de probl�me
     */
    public void create(Groupegrp data) throws DAOException{
    	EntityTransaction trans = null;
    	try {
    		trans = em.getTransaction();
    		trans.begin();
    		em.persist(data);
    		trans.commit();
    	} catch (Exception e) {
    		if(trans != null) trans.rollback();
    	}
           
    }

    /**
     * Met � jour le contenu correspondant � l'objet sur le support persistant (l'objet
     * avait d�j� une repr�sentation sur le support persistant).
     * @param data l'objet modifi� dont le contenu est � mettre � jour
     * @throws DAOException en cas de probl�me
     */
    public void update(Groupegrp data) throws DAOException{
    	EntityTransaction trans = null;
    	try {
    		trans = em.getTransaction();
    		trans.begin();
    		em.merge(data);
    		trans.commit();
    	} catch (Exception e) {
    		if(trans != null) trans.rollback();
    	}
    }

    /**
     * Efface du support persistant le contenu �quivalent � l'objet.
     * @param data l'objet � supprimer 
     * @throws DAOException en cas de probl�me
     */
    public void delete(Groupegrp data) throws DAOException{
    	EntityTransaction trans = null;
    	try {
    		trans = em.getTransaction();
    		trans.begin();
    		em.remove(data);
    		trans.commit();
    	} catch (Exception e) {
    		if(trans != null) trans.rollback();
    	}
    }
    
    /**
     * Construit le DAO pour la classe param�tr�e.
     * @throws DAOException en cas de probl�me
     */

}