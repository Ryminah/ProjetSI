package projet;

import javax.persistence.*;
import data.Soireesoi;

public class Soiree extends DAO<Soireesoi> {
		
    EntityManager em;
    
    
	public Soiree() throws DAOException {
		super();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("projet");
        em = emf.createEntityManager();
	}

	@Override
	public Soireesoi find(int id) throws DAOException {
		return em.find(Soireesoi.class,(short)id);
	}

	@Override
	public void create(Soireesoi data) throws DAOException {
        EntityTransaction tra = null;
        try {
            tra = em.getTransaction();
            tra.begin();
            em.persist(data);
            tra.commit();
        } catch (Exception e) {
            if(tra!=null) tra.rollback();
        }
	}

	@Override
	public void update(Soireesoi data) throws DAOException {
        EntityTransaction tra = null;
        try {
            tra = em.getTransaction();
            tra.begin();
            em.merge(data);
            tra.commit();
        } catch (Exception e) {
            if(tra!=null) tra.rollback();
        }
		
	}

	@Override
	public void delete(Soireesoi data) throws DAOException {
        EntityTransaction tra = null;
        try {
            tra = em.getTransaction();
            tra.begin();
            em.remove(data);
            tra.commit();
        } catch (Exception e) {
            if(tra!=null) tra.rollback();
        }
		
	}

}