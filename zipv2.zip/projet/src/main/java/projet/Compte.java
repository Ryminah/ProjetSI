package projet;

import data.Comptecpt;

import javax.persistence.*;

public class Compte {

	EntityManager em;
	
	public Compte() throws DAOException {
		
		
		super();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("projet");
		em = emf.createEntityManager();
	}

	public boolean verif() {
		Comptecpt cpt = em.find(Comptecpt.class, "toutouze");
		System.out.println(" -> " + cpt.getCptMdp());
		return false;
	}

	public Comptecpt find(String pseudo) throws DAOException {
		Comptecpt cpt = em.find(Comptecpt.class, pseudo);
		return cpt;
	}

	public void create(Comptecpt data) throws DAOException {
		EntityTransaction tra = null;
		try {
			tra = em.getTransaction();
			tra.begin();
			em.persist(data);
			tra.commit();
		} catch (Exception e) {
			if(tra!=null) tra.rollback();
		}

	}

	public void update(Comptecpt data) throws DAOException {
		EntityTransaction tra = null;
		try {
			tra = em.getTransaction();
			tra.begin();
			em.merge(data);
			tra.commit();
		} catch (Exception e) {
			if(tra!=null) tra.rollback();
		}

	}

	public void delete(Comptecpt data) throws DAOException {
		EntityTransaction tra = null;
		try {
			tra = em.getTransaction();
			tra.begin();
			em.remove(data);
			tra.commit();
		} catch (Exception e) {
			if(tra!=null) tra.rollback();
		}

	}
}