package projet;

import javax.persistence.*;
import data.Artisteart;

public class Artiste extends DAO<Artisteart> {
		
    EntityManager em;
    
    
	public Artiste() throws DAOException {
		super();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("projet");
        em = emf.createEntityManager();
	}

	@Override
	public Artisteart find(int id) throws DAOException {
		return em.find(Artisteart.class,(short)id);
	}

	@Override
	public void create(Artisteart data) throws DAOException {
        EntityTransaction tra = null;
        try {
            tra = em.getTransaction();
            tra.begin();
            em.persist(data);
            tra.commit();
        } catch (Exception e) {
            if(tra!=null) tra.rollback();
        }
	}

	@Override
	public void update(Artisteart data) throws DAOException {
        EntityTransaction tra = null;
        try {
            tra = em.getTransaction();
            tra.begin();
            em.merge(data);
            tra.commit();
        } catch (Exception e) {
            if(tra!=null) tra.rollback();
        }
		
	}

	@Override
	public void delete(Artisteart data) throws DAOException {
        EntityTransaction tra = null;
        try {
            tra = em.getTransaction();
            tra.begin();
            em.remove(data);
            tra.commit();
        } catch (Exception e) {
            if(tra!=null) tra.rollback();
        }
		
	}

}