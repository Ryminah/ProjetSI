package projet;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import data.Concertcon;

public class Concert extends DAO<Concertcon> {
	EntityManager em;

	public Concert() throws DAOException {
		super();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("projet");
		em = emf.createEntityManager();
		// TODO Auto-generated constructor stub
	}

	@Override
	public Concertcon find(int id) throws DAOException {
		return em.find(Concertcon.class, id);
	}

	@Override
	public void create(Concertcon data) throws DAOException {
		EntityTransaction trans = null;
		try {
			trans = em.getTransaction();
			trans.begin();
			em.persist(data);
			trans.commit();
		} catch (Exception e) {
			if (trans != null)
				trans.rollback();
		}

	}

	@Override
	public void update(Concertcon data) throws DAOException {
		EntityTransaction trans = null;
		try {
			trans = em.getTransaction();
			trans.begin();
			em.merge(data);
			trans.commit();
		} catch (Exception e) {
			if (trans != null)
				trans.rollback();
		}

	}

	@Override
	public void delete(Concertcon data) throws DAOException {
		EntityTransaction trans = null;
		try {
			trans = em.getTransaction();
			trans.begin();
			em.remove(data);
			trans.commit();
		} catch (Exception e) {
			if (trans != null)
				trans.rollback();

		}
	}
}