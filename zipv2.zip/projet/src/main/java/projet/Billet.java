package projet;

import data.Billetbil;

import javax.persistence.*;

public class Billet extends DAO<Billetbil> {

	EntityManager em;
	
	public Billet() throws DAOException {
		super();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("projet");
		em = emf.createEntityManager();
	}

	@Override
	public Billetbil find(int id) throws DAOException {
		Billetbil cpt = em.find(Billetbil.class, id);
		return cpt;
	}

	@Override
	public void create(Billetbil data) throws DAOException {
		EntityTransaction tra = null;
		try {
			tra = em.getTransaction();
			tra.begin();
			em.persist(data);
			tra.commit();
		} catch (Exception e) {
			if(tra!=null) tra.rollback();
		}
	}

	@Override
	public void update(Billetbil data) throws DAOException {
		EntityTransaction tra = null;
		try {
			tra = em.getTransaction();
			tra.begin();
			em.merge(data);
			tra.commit();
		} catch (Exception e) {
			if(tra!=null) tra.rollback();
		}
	}

	@Override
	public void delete(Billetbil data) throws DAOException {
		EntityTransaction tra = null;
		try {
			tra = em.getTransaction();
			tra.begin();
			em.remove(data);
			tra.commit();
		} catch (Exception e) {
			if(tra!=null) tra.rollback();
		}
	}

}
