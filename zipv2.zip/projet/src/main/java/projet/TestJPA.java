package projet;

import data.Comptecpt;

import javax.persistence.*;

public class TestJPA {

   public static void main(String argv[]) throws Exception {

      // charge le gestionnaire d'entités lié à l'unité de persistance "SportsPU"
      EntityManagerFactory emf = Persistence.createEntityManagerFactory("projet");
      EntityManager em = emf.createEntityManager();
      System.out.println("PU chargée");
      
      Comptecpt cpt = em.find(Comptecpt.class, "toutouze" );
      System.out.println(" -> " + cpt.getCptMdp());
   }
}
